#include <at89c5131.h>
#include<lcd.h>

sfr A = 0xE0;
sbit r0=P3^4;
sbit r1=P3^5;
sbit r2=P3^6;
sbit r3=P3^7;
sbit c0=P3^3;
sbit c1=P3^2;
sbit c2=P3^1;
sbit c3=P3^0;
sbit LED1 = P0^7;

void delaydebounce(){
	msdelay(20);
}
void clock_gen(unsigned int tl0, unsigned int th0, char key)
{	
	TL0 = tl0;
	TH0 = th0;
	TR0 = 1;
	TR1 = 1; //start timer 1
	
			LED1 = 1;
			while(TF0 == 0);
			LED1 = 0;
		  TF0 = 0;
		  TR0 = 0;
		  TL0 = tl0;
	    TH0 = th0;	
      TR0 = 1;	  
			while(TF0 == 0);
		  TR0 = 0;
	   	TF0 = 0;   
		  TL0 = tl0;
	    TH0 = th0;
      TR0 = 1;	
         		
  
}
unsigned char getkey(unsigned int tl0, unsigned int th0){
	
	unsigned char keypad[4][4] = {{'1','2','3','A'},{'4','5','6','B'},{'7','8','9','C'},{'*','0','#','D'}};
	unsigned int checkrow[4] = {0xEF,0xDF,0xBF,0x7F};
	unsigned int row = 0;
	unsigned int col;
	unsigned char key;
	// intialise rows to 0 and cols to 1
	P3 = 0x0F;
	// read the column
	while(1){
	while(c0 != 1 || c1 != 1 || c2 != 1 || c3 != 1 ){
			// keep reading
			// here we are checking that previous key is released
		  // when all cols will become 1 , exit the loop;		
		clock_gen(tl0,th0,'1');
	}
	// read the column
	while(c0 == 1 && c1 == 1 && c2 == 1 && c3 == 1){
			// keep reading 
		  // when any key pressed exit loop
		lcd_cmd(0x01);	// LCD clear
		msdelay(4);
	
	}
	// now we will give a debounce delay of 20 ms
	delaydebounce();
	// again read the cols
	// if any key down then break the loop
	if(c0 != 1 || c1 != 1 || c2 != 1 || c3 != 1){
		break;
	}
}
	
	
	P3 = checkrow[0];
	while(c0 == 1 && c1 == 1 && c2 == 1 && c3 == 1){
		P3 = checkrow[++row];	
	}
	if(c0 == 0)
		col = 0;
	else if(c1==0)
		col = 1;
	else if(c2==0)
		col = 2;
	else if(c3==0)
		col = 3;
	
	key = keypad[row][col];

	return key;

}



//Main function
void main(void)
{																			
		
		lcd_init();
		lcd_cmd(0x80);													//Move cursor to first line
		msdelay(4);

		while(1){
			char key = getkey();
			if(key == '1'){
				
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
				lcd_write_string("Sa   ");
				clock_gen(0xBA,0xEF,'1');	

			}
			else if(key == '2'){                                                   
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
				lcd_write_string("Re   ");
				clock_gen(0x89,0xF1,'2');	
	

			}
			else if(key == '3'){
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
				lcd_write_string("Ga   ");
				clock_gen(0xFB,0xF2,'3');	
	

			}
			else if(key == '4'){
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
				lcd_write_string("Ma   ");
			  clock_gen(0xCB,0xF3,'4');	
	
			}
			else if(key == '5'){
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
				lcd_write_string("Pa   ");
				clock_gen(0x27,0xF5,'5');	
	
	
			}
			else if(key == '6'){
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
				lcd_write_string("Dha  ");
				clock_gen(0x3C,0xF6,'6');	


			}
			else if(key == '7'){
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
				lcd_write_string("Ni   ");
				clock_gen(0x52,0xF7,'7');	
	
		
			}
			else if(key == '8'){
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
				lcd_write_string("Sa   ");
				clock_gen(0xDD,0xF7,'8');	
	
			}
			else if(key == '9'){
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
				lcd_write_string("Silence");
				
			}
			else{
				lcd_cmd(0x01);	// LCD clear
				msdelay(4);
			}
		}
}